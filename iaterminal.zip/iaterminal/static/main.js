let ws;
let manualCommandsSet = new Set();

window.onload = () => {
  ws = new WebSocket(`ws://${window.location.host}/ws`);

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    const output = document.getElementById("output");
    const chat = document.getElementById("chatOutput");
    const tree = document.getElementById("tree");

    if (msg.type === "stdout" || msg.type === "stderr" || msg.type === "status") {
      output.innerHTML += `<div>${msg.text}</div>`;
      output.scrollTop = output.scrollHeight;
    } 
    else if (msg.type === "ai_response") {
      chat.innerHTML += `<div><b>IA:</b> ${msg.text}</div>`;
      chat.scrollTop = chat.scrollHeight;
    }
    else if (msg.type === "manual_command_saved") {
      if (!manualCommandsSet.has(msg.cmd)) {
        manualCommandsSet.add(msg.cmd);
        addCommandButton(msg.cmd, chat);
      }
    }
    else if (msg.type === "tree_update") {
      tree.innerHTML = `<b>${msg.path}</b><br>`;
      msg.files.forEach(f => {
        const btn = document.createElement("div");
        btn.className = "tree-btn";
        btn.textContent = f;
        btn.onclick = () => {
          let cmd = f.endsWith("/") ? `cd ${f}` : `nano ${f}`;
          executeCommand(cmd);
          ws.send(JSON.stringify({ type: "update_tree", path: f.endsWith("/") ? f : "." }));
        }
        tree.appendChild(btn);
      });
    }
  };

  document.getElementById("manualInput").addEventListener("keydown", e => { if (e.key==="Enter") sendManual(); });
  document.getElementById("prompt").addEventListener("keydown", e => { if (e.key==="Enter") askAI(); });
  document.getElementById("password").addEventListener("keydown", e => { if (e.key==="Enter") connectSSH(); });
};

function connectSSH() {
  const host = document.getElementById("host").value;
  const user = document.getElementById("user").value;
  const password = document.getElementById("password").value;
  ws.send(JSON.stringify({ type: "connect", host, user, password }));
}

function askAI() {
  const text = document.getElementById("prompt").value;
  document.getElementById("prompt").value = "";
  ws.send(JSON.stringify({ type: "instruction", text }));
}

function executeCommand(cmd) {
  ws.send(JSON.stringify({ type: "exec_command", cmd }));
}

function sendManual() {
  const cmd = document.getElementById("manualInput").value.trim();
  if (!cmd) return;
  document.getElementById("manualInput").value = "";
  ws.send(JSON.stringify({ type: "exec_command", cmd }));

  if (!cmd.startsWith("cd ") && !manualCommandsSet.has(cmd)) {
    manualCommandsSet.add(cmd);
    addCommandButton(cmd, document.getElementById("chatOutput"));
  }
}

function addCommandButton(cmd, container) {
  const btn = document.createElement("div");
  btn.className = "cmd-btn";
  btn.textContent = cmd;
  btn.onclick = () => executeCommand(cmd);
  container.appendChild(btn);
}

function sendFile() {
  const path = document.getElementById("filePath").value.trim();
  const content = document.getElementById("fileContent").value;
  if (!path) return alert("Informe o caminho do arquivo!");
  ws.send(JSON.stringify({ type: "overwrite_file", path, content }));
}
