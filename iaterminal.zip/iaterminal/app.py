import os
import json
import re
import threading
import paramiko
from flask import Flask, render_template
from flask_sock import Sock
from openai import OpenAI
from dotenv import load_dotenv

# 🔹 Carrega .env
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# 🔹 Inicializa Flask e WebSocket
app = Flask(__name__)
sock = Sock(app)
client = OpenAI(api_key=OPENAI_API_KEY)

ssh_client = None
ssh_shell = None  # canal interativo SSH

# 🔹 Regex para remover sequências ANSI
ansi_escape = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')

# 🔹 Histórico persistente
HISTORY_FILE = "commands_history.json"

def save_command(host, user, cmd):
    key = f"{host}_{user}"
    try:
        with open(HISTORY_FILE, "r") as f:
            history = json.load(f)
    except:
        history = {}
    history.setdefault(key, []).append(cmd)
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

def get_history(host, user):
    key = f"{host}_{user}"
    try:
        with open(HISTORY_FILE, "r") as f:
            history = json.load(f)
        return history.get(key, [])
    except:
        return []

def connect_ssh(host, user, key=None, password=None):
    global ssh_client, ssh_shell
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    if key:
        ssh_client.connect(host, username=user, key_filename=key)
    else:
        ssh_client.connect(host, username=user, password=password)

    ssh_shell = ssh_client.invoke_shell()
    ssh_shell.settimeout(0.0)
    return ssh_shell

def stream_terminal(sock):
    global ssh_shell
    while True:
        if ssh_shell and ssh_shell.recv_ready():
            data = ssh_shell.recv(4096).decode(errors="ignore")
            clean = ansi_escape.sub('', data)
            sock.send(json.dumps({"type": "stdout", "text": clean}))
        elif ssh_shell and ssh_shell.closed:
            sock.send(json.dumps({"type": "status", "text": "Conexão SSH encerrada."}))
            break

def ask_openai(prompt):
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": (
                "Você é um assistente técnico que ajuda o usuário a operar no Linux. "
                "Explique claramente ao usuário, mas não execute comandos automaticamente."
            )},
            {"role": "user", "content": prompt}
        ]
    )
    return completion.choices[0].message.content.strip()

def list_dir(path="."):
    if ssh_shell:
        stdin, stdout, stderr = ssh_client.exec_command(f"ls -p {path}")
        files = stdout.read().decode().splitlines()
        return files
    return []

@app.route("/")
def index():
    return render_template("index.html")

@sock.route("/ws")
def ws(sock):
    global ssh_shell
    current_host = None
    current_user = None

    while True:
        data = sock.receive()
        if not data:
            continue
        msg = json.loads(data)

        # 🔌 Conexão SSH
        if msg["type"] == "connect":
            try:
                host = msg["host"]
                user = msg["user"]
                password = msg.get("password")
                current_host = host
                current_user = user
                connect_ssh(host, user, password=password)
                sock.send(json.dumps({"type": "status", "text": f"🔌 Conectado a {host}"}))

                # envia histórico salvo
                saved_cmds = get_history(host, user)
                for cmd in saved_cmds:
                    if not cmd.startswith("cd "):  # não criar botão de cd
                        sock.send(json.dumps({"type": "manual_command_saved", "cmd": cmd}))

                # envia árvore inicial do diretório home
                files = list_dir(".")
                sock.send(json.dumps({"type": "tree_update", "path": ".", "files": files}))

                threading.Thread(target=stream_terminal, args=(sock,), daemon=True).start()
            except Exception as e:
                sock.send(json.dumps({"type": "status", "text": f"Erro ao conectar: {str(e)}"}))

        # 🤖 IA (somente conversa)
        elif msg["type"] == "instruction":
            ai_resp = ask_openai(msg["text"])
            sock.send(json.dumps({"type": "ai_response", "text": ai_resp, "commands": []}))

        # 🖥️ Comando manual
        elif msg["type"] == "exec_command":
            cmd = msg.get("cmd", "") + "\n"
            if ssh_shell:
                ssh_shell.send(cmd)
                if current_host and current_user:
                    save_command(current_host, current_user, cmd.strip())
            else:
                sock.send(json.dumps({"type": "status", "text": "⚠️ Não há conexão SSH ativa"}))

        # 🌳 Atualizar árvore
        elif msg["type"] == "update_tree":
            path = msg.get("path", ".")
            files = list_dir(path)
            sock.send(json.dumps({"type": "tree_update", "path": path, "files": files}))

        # 📝 Sobrescrever arquivo remoto
        elif msg["type"] == "overwrite_file":
            path = msg.get("path")
            content = msg.get("content", "")
            if ssh_shell:
                cmd = f"cat > {path} <<'EOF'\n{content}\nEOF\n"
                ssh_shell.send(cmd)
                sock.send(json.dumps({"type": "status", "text": f"Arquivo {path} atualizado."}))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5010, debug=True)
